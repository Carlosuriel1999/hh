//
//  producto.swift
//  ProyectoRopa
//
//  Created by Laboratorio UNAM-Apple 16 on 04/10/18.
//  Copyright © 2018 Agustin. All rights reserved.
//

import Foundation

struct Producto{
    var nombre: String
    var desc: String
    var costo: Double
    var imagen: String
    
}

var myIndex = 0

let nike = Producto(nombre: "Tennis Nike", desc: "color blanco", costo: 450.00, imagen: "nike")

let jordan = Producto(nombre: "Tennis jordan", desc: "color blanco", costo: 1200.00, imagen: "jordan")

let adidas = Producto(nombre: "Tennis adidas", desc: "Color negro", costo: 500.00, imagen: "adidas")

let convers = Producto(nombre: "Tennis convers", desc: "Color blanco", costo: 220.00, imagen: "convers")

let champion = Producto(nombre: "Tennis champion", desc: "Color rojo vivo", costo: 220.00, imagen: "champion")


var tennis = [nike, jordan, adidas, convers, champion]
