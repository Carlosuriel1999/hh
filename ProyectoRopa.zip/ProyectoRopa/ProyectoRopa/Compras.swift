//
//  Compras.swift
//  ProyectoRopa
//
//  Created by Laboratorio UNAM-Apple 16 on 04/10/18.
//  Copyright © 2018 Agustin. All rights reserved.
//

import Foundation
import UIKit

struct ProductoC{
    var nombres: String
    var precioT: Double
    var cantidad: Int
}
var cuentaT: Double = 0.00
var listaProducto: [ProductoC] = []

