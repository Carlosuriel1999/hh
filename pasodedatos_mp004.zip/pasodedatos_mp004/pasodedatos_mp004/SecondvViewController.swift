//
//  SecondvViewController.swift
//  pasodedatos_mp004
//
//  Created by Carlos uriel on 2/14/19.
//  Copyright © 2019 Usuario invitado. All rights reserved.
//

import UIKit

class SecondvViewController: UIViewController {

    var dato: String = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .blue

        print(dato)
    }

}
