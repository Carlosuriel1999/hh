//
//  ContenidoVC.swift
//  FoodFI
//
//  Created by Macbook on 11/29/18.
//  Copyright © 2018 iosdevlab. All rights reserved.
//

import UIKit

class ContenidoVC: UIViewController {

    @IBOutlet weak var Constraint: NSLayoutConstraint!
    var sideMenuOpen = false
    override func viewDidLoad() {
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(toggleSideMenu), name: NSNotification.Name("ToggleSideMenu"), object: nil)
       
    }
    
    @objc func toggleSideMenu(){
        if sideMenuOpen{
            sideMenuOpen = false
            Constraint.constant = -240
        }else {
            sideMenuOpen = true
            Constraint.constant = 0
        }
        UIView.animate(withDuration: 0.3){
            self.view.layoutIfNeeded()
        }
    }
    

  

}
